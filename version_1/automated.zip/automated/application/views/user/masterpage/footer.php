	<div id="preloader">
        <div id="status">&nbsp;</div>
    </div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/automated/js/script.js"></script>
    <script type='text/javascript'>
		var baseURL= "<?php echo base_url();?>";
	</script>
    <script>
        $.cookie("test", 0);
    </script>
  </body>
</html>