<h1>User Dashboard</h1>
<form action="User/logout" method="post">
	<button type="submit">Logout</button>
</form>